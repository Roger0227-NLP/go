#pragma once
#include "IMonitor.h"
#include "Log.h"

#include <fstream>
#include <dirent.h>
class CPUMonitor :public IMonitor{

	
	//cpu����
	struct AllStat {
		uint64_t user;
		uint64_t nice;
		uint64_t system;
		uint64_t idle;
		uint64_t irq;
		uint64_t softirq;
		uint64_t stealstolen;
		uint64_t guest;

		AllStat():user(0),nice(0),system(0),idle(0),irq(0),softirq(0),stealstolen(0),guest(0){}
		uint64_t operator-(const AllStat& p) {
			return user - p.user + nice - p.nice + system - p.system + idle - p.idle + softirq - p.softirq + stealstolen - p.stealstolen + guest - p.stealstolen;
		}
	};
	//���̿���
	struct ProcessTime {
		std::string processName;
		pid_t pid;
		long unsigned int utime;
		long unsigned int stime;
		long int cutime;
		long int cstime;


		ProcessTime():pid(0), processName(""),utime(0),stime(0),cutime(0),cstime(0){}
	};

	struct ThreadTime {
		long int threadID;
		long int utime;
		long int stime;

		ThreadTime() :threadID(0), stime(0), utime(0) {}
	};

	struct ProcessMemory {
		pid_t pid;
		int usedMemory;
	};

	int GetMemoryByPid(pid_t pid);

	void GetThreadIDByPid(pid_t pid, std::vector<int>& threadID);
	void GetNowThreadOfProcessTime(std::unordered_map<pid_t, std::vector<ThreadTime>>&);
	void ReadCPUAllStat(AllStat & allCPUStat);
	void ReadProcessStat(std::unordered_map<pid_t, ProcessTime>  & processTimes);
public:

	virtual void Calculate();
	virtual void WriteLogs();
	virtual void SetLogFiles();
	virtual void FileOpenReady();

	~CPUMonitor(){}

private:
	
	static AllStat _oldTotalCpuTime;
	static AllStat _newTotalCpuTime;

	static uint64_t _totalCpuTime;

	static std::unordered_map<pid_t,ProcessTime> _oldProcessTimes;
	static std::unordered_map<pid_t,ProcessTime> _newProcessTimes;

	
	static std::unordered_map<pid_t, std::vector<ThreadTime>> _oldThreadTimes;
	static std::unordered_map<pid_t, std::vector<ThreadTime>> _newThreadTimes;

	static std::unordered_map<pid_t, uint64_t> _processTimeMap;
	static std::unordered_map<pid_t, std::vector<ThreadTime>> _processThreadMap;


	
};

