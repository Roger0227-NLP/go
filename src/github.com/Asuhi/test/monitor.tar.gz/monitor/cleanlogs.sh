rm log/*.log
